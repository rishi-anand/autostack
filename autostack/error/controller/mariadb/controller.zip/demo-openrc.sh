export OS_TENANT_NAME=demo
export OS_USERNAME=demo
export OS_PASSWORD=welcome
export OS_AUTH_URL=http://controller10:5000/v2.0
