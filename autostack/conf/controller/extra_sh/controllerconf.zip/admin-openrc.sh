export OS_TENANT_NAME=admin
export OS_USERNAME=admin
export OS_PASSWORD=welcome
export OS_AUTH_URL=http://controller10:35357/v2.0
