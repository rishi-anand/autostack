#!/bin/bash


apt-get install ntp




exit