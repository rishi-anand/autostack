#!/bin/bash

echo "I am in network"
#sudo apt-get update
echo "ye bye"

exit
